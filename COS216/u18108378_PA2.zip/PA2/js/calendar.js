var loader = document.querySelector(".loader");

window.addEventListener("load", vanish);

function vanish() {
	loader.classList.add("disppear");
}


var date = new Date();
var mm = date.getMonth();
var yyyy = date.getFullYear();

window.onload = function() {
	var day = ['Mon', 'Tue', 'Wed', 'Thur', 'Fri', 'Sat', 'Sun'];
	var month = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
	var firstDate = month[mm] + " " + 1 + " " + yyyy;

	var temp = new Date(firstDate).toDateString();
	var firstDay = temp.substring(0, 3);
	var dd = day.indexOf(firstDay);
	var days = new Date(yyyy, mm + 1, 0).getDate();
	set_calendar(dd, mm, yyyy, days, month);
};


function set_calendar(dd, mm, yyyy, days, month) {
	var mon = document.getElementById("month");
	var year = document.getElementById("year");
	mon.innerHTML = month[mm] + " " + yyyy;
	year.innerHTML = year[yyyy];

	var cell;
	var count = 1;
	for (var row = 0; row <= 7; row++) {
		if (count > days) {
			break;
		}
		for (var col = 1; col <= 7; col++) {
			if (count > days) {
				break;
			}
			cell = row + "" + col;
			console.log(cell);
			var curr = document.getElementById(cell);
			if (row == 1 && col == dd + 1) {
				curr.innerHTML = count;
				count++;
			} else if (row == 1 && col > dd) {
				curr.innerHTML = count;
				count++;
			} else if (row > 1) {
				curr.innerHTML = count;
				count++;
			}

		}
	}

}

//  function next()
//  {
//      mm++;
//      location.reload();
//  }

//  function prev()
//  {
//      mm--;
//      location.reload();
//  }